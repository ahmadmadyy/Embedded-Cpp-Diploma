/*
 ============================================================================
 Name        : EthIf.c
 Author      : Nouran Hussein
 Version     :
 Description : Source File for Ethernet Interface Module Supporting Wireless Ethernet Driver.
 ============================================================================
 */
#include "../../V2xEthIf/inc/EthIf.h"

#include "../../DET/inc/Det.h"


#define INVALID_BUFFER_INDEX    0xFFFFFFFFUL
#define MAX_ETHIF_HANDLE    1
#define MAX_OWNERS          256
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)

/* AUTOSAR Version checking between Det and Dio Modules */
#if ((DET_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
 || (DET_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
 || (DET_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of Det.h does not match the expected version"
#endif

#endif
typedef struct {
    uint32 frameType;
    uint32  bufferIdx;
}EthIfCurrentDataInfoType;
typedef struct {
    EthIfCurrentDataInfoType ethIfCurrentDataInfo[MAX_OWNERS]; /* Mapping from buffer index to Frame type*/
}EthIfCurrentStateType;

EthIfCurrentStateType EthIfCurrentState;

STATIC const EthIf_ConfigType* EthIf_ConfigPointer= NULL_PTR;

STATIC EthIf_StateType EthIf_State= ETHCTRL_STATE_UNINIT;

STATIC Eth_ModeType ethmode = ETH_MODE_ACTIVE;

/************************************************************************************
* Service Name: EthIf_Init
* Service ID[hex]: 0x01
* Sync/Async: Synchronous
* Reentrancy: Non reentrant
* Parameters (in): ConfigPtr - Pointer to post-build configuration data
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description:  Function to Initialize the Ethernet Interface module.
* Requirements: SWS_EthIf_00025, SWS_EthIf_00114
************************************************************************************/

void EthIf_Init(const EthIf_ConfigType * ConfigPtr)
{ uint8 i;

/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* check if the input configuration pointer is not a NULL_PTR */
	if (NULL_PTR == ConfigPtr)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_INIT_SID,
		     ETHIF_E_PARAM_POINTER);
	}
	else
#endif
	{
		/*
		 * Set the module state to initialized and point to the PB configuration structure using a global pointer.
		 * This global pointer is global to be used by other functions to read the PB configuration structures
		 */
		 EthIf_State= ETHCTRL_STATE_INIT;
		/* setting the configuration parameters */
		 EthIf_ConfigPointer = ConfigPtr;

		for (i=0; i < EthIf_ConfigPointer->EthIfOwnersCount; i++) {
		        EthIfCurrentState.ethIfCurrentDataInfo[i].frameType = EthIf_ConfigPointer->EthIfOwnerCfg[i].EthIfFrameType;
		        EthIfCurrentState.ethIfCurrentDataInfo[i].bufferIdx = INVALID_BUFFER_INDEX;
		    }

	}
}


/************************************************************************************
* Service Name: EthIf_ProvideTxBuffer
* Service ID[hex]: 0x09
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): CtrlIdx, FrameType, Priority
* Parameters (inout): LenBytePtr
* Parameters (out): BufIdxPtr, BufPtr
* Return value: BUFREQ_OK: success
				BUFREQ_V2X_E_NOT_OK: development error detected
				BUFREQ_E_BUSY: all buffers in use
				BUFREQ_E_OVFL: requested buffer too large
* Description:  Function to Provides access to a transmit buffer of the specified Wireless Ethernet controller.
* Requirements: SWS_EthIf_00146, SWS_EthIf_00068,SWS_EthIf_00069, SWS_EthIf_00070, SWS_EthIf_00071, SWS_EthIf_00072, SWS_EthIf_00073
************************************************************************************/
BufReq_ReturnType EthIf_ProvideTxBuffer( uint8 CtrlIdx, Eth_FrameType FrameType, uint8 Priority, Eth_BufIdxType* BufIdxPtr, uint8** BufPtr, uint16*LenBytePtr )
{
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Driver is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_UNINIT);
		return BUFREQ_V2X_E_NOT_OK;
	}

	/* Check the parameter CtrlIdx for being valid*/
	if(CtrlIdx>EthIf_ConfigPointer->numberControllers){

		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_INV_CTRL_IDX);
		return BUFREQ_V2X_E_NOT_OK;

	}
 /* check the parameter BufIdxPtr for being valid */
	if(BufIdxPtr==NULL_PTR){
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_PARAM_POINTER);

		return BUFREQ_V2X_E_NOT_OK;


	}
	 /* check the parameter BufPtr for being valid */

	if(BufPtr==NULL_PTR){
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_PARAM_POINTER);

			return BUFREQ_V2X_E_NOT_OK;


		}
 /* check the parameter LenBytePtr for being valid */

	if(LenBytePtr==NULL_PTR)
	{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_PARAM_POINTER);

			return BUFREQ_V2X_E_NOT_OK;


	}


#endif

/* Check that Wireless Ethernet Standard is ON */
#if(ETHIF_ENABLE_WETH_API==STD_ON)
/* No VLAN Support */

return WEth_ProvideTxBuffer(EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId,Priority,BufIdxPtr,BufPtr,LenBytePtr);

#elif return BUFREQ_V2X_E_NOT_OK;
#endif

}

/************************************************************************************
* Service Name: EthIf_Transmit
* Service ID[hex]: 0x0a
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): CtrlIdx, BufIdx, FrameType, TxConfirmation, LenByte, PhysAddrPtr
* Parameters (inout): None
* Parameters (out): None
* Return value: V2X_E_OK: success
                V2X_E_NOT_OK: transmission failed
* Description:  Triggers transmission of a previously filled transmit buffer
* Requirements: SWS_EthIf_00250, SWS_EthIf_00076,SWS_EthIf_00077, SWS_EthIf_00078, SWS_EthIf_00079, SWS_EthIf_00080
************************************************************************************/

Std_ReturnType EthIf_Transmit( uint8 CtrlIdx, Eth_BufIdxType BufIdx, Eth_FrameType FrameType, boolean TxConfirmation, uint16 LenByte, const uint8* PhysAddrPtr ){
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TRANSMIT_SID, ETHIF_E_UNINIT);
		return V2X_E_NOT_OK;
	}
	/* Check the parameter CtrlIdx for being valid*/
	if(CtrlIdx > EthIf_ConfigPointer->numberControllers){

			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TRANSMIT_SID, ETHIF_E_INV_CTRL_IDX);
			return V2X_E_NOT_OK;
	}

    /* Check if Buffer Index not exceeds the max buffer number */
	if(BufIdx >EthIf_ConfigPointer->EthCtrls[CtrlIdx].MaxTxBufsTotal){


		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TRANSMIT_SID,ETHIF_E_INV_PARAM);

		return V2X_E_NOT_OK;
	}

	/* Check that Physical target address (MAC address) not null */
	if(NULL_PTR == PhysAddrPtr)
	{

		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TRANSMIT_SID, ETHIF_E_PARAM_POINTER);
	    return V2X_E_NOT_OK;
	 }
#endif

	Std_ReturnType ret;
    uint8 i;

    /* Check that Data length in byte not exceeds Max Transmit Unit */
if(EthIf_ConfigPointer->EthCtrls[CtrlIdx].CtrlMtu>=LenByte)
{
		/* Check that Wireless Ethernet Standard is ON */
		#if(ETHIF_ENABLE_WETH_API==STD_ON)
		/* No VLAN Support */
		if(ethmode == ETH_MODE_ACTIVE || ethmode == ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST)
			ret = WEth_Transmit(EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId, BufIdx, FrameType, TxConfirmation, LenByte, PhysAddrPtr);
		#elif return V2X_E_NOT_OK;
		#endif

		/* check if the GeoNetwork TX Confirmation call back function is not null and transmission is OK */
		 if ((V2X_E_OK == ret) && (EthIf_ConfigPointer->EthIfULTxConfirmation != NULL_PTR))
		 {

				 for (i=0; i < EthIf_ConfigPointer->EthIfOwnersCount; i++)
				 {
						 /* 	Search about the owner of frame type */
						 if ((FrameType == EthIfCurrentState.ethIfCurrentDataInfo[i].frameType))
						 {
								 if (TRUE == TxConfirmation)
								 {
									 /* Currently used buffer index stored for the requested frame type */
									 EthIfCurrentState.ethIfCurrentDataInfo[i].bufferIdx = BufIdx;
								 }
								 else
								 {
									 /* Reset the buffer index when no TxConfirmation is requested */
									  EthIfCurrentState.ethIfCurrentDataInfo[i].bufferIdx = INVALID_BUFFER_INDEX;
								  }

								  break;
						   }

				   }
             }
}
else
{
	  ret = V2X_E_NOT_OK;
}

return ret;
}
/************************************************************************************
* Service Name: EthIf_RxIndication
* Service ID[hex]: 0x10
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx, FrameType, IsBroadcast, PhysAddrPtr, DataPtr, LenByte
* Parameters (inout): None
* Parameters (out): None
* Return value:None
* Description: Handles a received frame received by the indexed controller
* Requirements: SWS_EthIf_0086, SWS_EthIf_00087,SWS_EthIf_00088, SWS_EthIf_00151, SWS_EthIf_00145
************************************************************************************/

void EthIf_RxIndication( uint8 CtrlIdx, Eth_FrameType FrameType, boolean IsBroadcast, const uint8* PhysAddrPtr, Eth_DataType* DataPtr, uint16 LenByte ) {
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_RX_INDICATION_SID, ETHIF_E_UNINIT);
		return;
	}
	/* Check the parameter CtrlIdx for being valid*/
	if(CtrlIdx > EthIf_ConfigPointer->numberControllers)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_RX_INDICATION_SID, ETHIF_E_INV_CTRL_IDX);
	    return;
	}
	/* Check the parameter DataPtr for being valid*/
	if(NULL_PTR == DataPtr)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_RX_INDICATION_SID, ETHIF_E_PARAM_POINTER);
	    return;
	}

#endif

	uint8 i;
	uint8 handle;

	for(i =0 ; i <  EthIf_ConfigPointer->EthIfOwnersCount; i ++)
	{
		if(FrameType == EthIf_ConfigPointer->EthIfOwnerCfg[i].EthIfFrameType)
		{
			/* get The Frame Owner Index */
			handle=EthIf_ConfigPointer->EthIfOwnerCfg[i].EthIfFrameOwnerConfig;
			/* Call The GeoNetwork function that correspond to the owner */
			EthIf_ConfigPointer->EthIfULRxIndication[handle](CtrlIdx, FrameType, IsBroadcast, PhysAddrPtr, DataPtr, LenByte);

		 }
	}



}


/* Check if the Polling Method is used */
#if (ETHIF_ENABLE_TX_INTERRUPT == STD_OFF)
/************************************************************************************
* Service Name: EthIf_MainFunctionTx
* Service ID[hex]: 0x21
* Description: The function issues transmission confirmations in polling mode. It checks also for transceiver state changes.
* Requirements: SWS_EthIf_00100, SWS_EthIf_00101
************************************************************************************/
void EthIf_MainFunctionTx( void ){
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_MAIN_FUNCTION_TX_SID, ETHIF_E_UNINIT);
		return;
	}
#endif

uint8 CtrlIdx;

/* Check if Transmission Succeed */
for(CtrlIdx=0; CtrlIdx < EthIf_ConfigPointer->numberControllers; CtrlIdx++)
{
	WEth_TxConfirmation(EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId );
}

}

#endif



/* Check if the Polling Method is used */
#if (ETHIF_ENABLE_RX_INTERRUPT == STD_OFF)
/************************************************************************************
* Service Name: EthIf_MainFunctionRx
* Service ID[hex]: 0x20
* Description: The function checks for new received frames and issues reception indications in polling mode.
* Requirements: SWS_EthIf_00099
************************************************************************************/
void EthIf_MainFunctionRx( void ) {
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_MAIN_FUNCTION_RX_SID, ETHIF_E_UNINIT);
		return;
	}
#endif

	Eth_RxStatusType RxStatusPtr;
	RxStatusPtr = ETH_NOT_RECEIVED;
	uint8 i;
	uint8 CtrlIdx;

	for(CtrlIdx = 0u; CtrlIdx < EthIf_ConfigPointer->numberControllers; CtrlIdx++)
	{
			 /* Receive first Frame */
			WEth_Receive(EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId, &RxStatusPtr);
			  /* check for more than one frame */
			for(i= 0; i < ETHIF_RX_INDICATION_ITERATIONS; i++)
			{
				if(RxStatusPtr == ETH_RECEIVED_MORE_DATA_AVAILABLE)
				{
					WEth_Receive(EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId, &RxStatusPtr);
				}
				else
				{
					break;

				}


			}
	}
}

#endif

#if((ETHIF_VERSION_INFO_API == STD_ON) && (ETHIF_VERSION_INFO_API_MACRO == STD_OFF))
/************************************************************************************
* Service Name: EthIf_GetVersionInfo
* Service ID[hex]: 0x0b
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): None
* Parameters (inout): None
* Parameters (out): VersionInfoPtr
* Return value:None
* Description: Returns the version information of this module
* Requirements: SWS_EthIf_00127
************************************************************************************/
void EthIf_GetVersionInfo( Std_VersionInfoType* VersionInfoPtr )
{
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)

    if(NULL_PTR == VersionInfoPtr)
    {
    	Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID,ETHIF_GET_VERSION_INFO_SID,ETHIF_E_PARAM_POINTER);
        return;
    }
#endif
    VersionInfoPtr->moduleID = ETHIF_MODULE_ID;  /* Module ID of ETHIF */
    VersionInfoPtr->vendorID = ETHIF_VENDOR_ID;  /* Vendor ID*/

    /* return the Software Version numbers */
    VersionInfoPtr->sw_major_version = ETHIF_SW_MAJOR_VERSION;
    VersionInfoPtr->sw_minor_version = ETHIF_SW_MINOR_VERSION;
    VersionInfoPtr->sw_patch_version = ETHIF_SW_PATCH_VERSION;
}
#endif

/************************************************************************************
* Service Name: EthIf_SetControllerMode
* Service ID[hex]: 0x03
* Sync/Async: Asynchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx,
*                  CtrlMode: ETH_MODE_DOWN: disable the controller, ETH_MODE_ACTIVE: enable the controller, ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST: enable the controller and request a wake-up on the network.
* Parameters (inout): None
* Parameters (out): None
* Return value:V2X_E_OK: success
               V2X_E_NOT_OK: controller mode could not be changed
* Description: Enables / disables the indexed controller.
* Requirements: SWS_EthIf_00036,SWS_EthIf_00037
************************************************************************************/
Std_ReturnType EthIf_SetControllerMode( uint8 CtrlIdx, Eth_ModeType CtrlMode )
{
Std_ReturnType ret = V2X_E_NOT_OK;
/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CONTROLLER_MODE_SID, ETHIF_E_UNINIT);
		return V2X_E_NOT_OK;
	}

	if(CtrlIdx >EthIf_ConfigPointer->numberControllers)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CONTROLLER_MODE_SID, ETHIF_E_INV_CTRL_IDX);
		return V2X_E_NOT_OK;
	}
#endif

/* Check that Wireless Ethernet Standard is ON */
#if(ETHIF_ENABLE_WETH_API==STD_ON)
/* No VLAN Support */

	if(CtrlMode == ETH_MODE_TX_OFFLINE  && (ethmode != ETH_MODE_ACTIVE || ethmode != ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST) )
		return V2X_E_NOT_OK;

	else if((CtrlMode == ETH_MODE_ACTIVE || CtrlMode == ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST) && (ethmode == ETH_MODE_ACTIVE || ethmode == ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST))
		return V2X_E_OK;

ethmode = CtrlMode;
ret = WEth_SetControllerMode(EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId, CtrlMode);

#elif
return V2X_E_NOT_OK;
#endif
return ret;
}


/************************************************************************************
* Service Name: EthIf_GetControllerMode
* Service ID[hex]: 0x04
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx
* Parameters (inout): None
* Parameters (out): CtrlMode: ETH_MODE_DOWN: disable the controller, ETH_MODE_ACTIVE: enable the controller.
* Return value:V2X_E_OK: success
               V2X_E_NOT_OK: controller mode could not be changed
* Description: Obtains the state of the indexed controller.
* Requirements: SWS_EthIf_00040, SWS_EthIf_00041,SWS_EthIf_00042, SWS_EthIf_00043
************************************************************************************/
Std_ReturnType EthIf_GetControllerMode( uint8 CtrlIdx, Eth_ModeType* CtrlModePtr )
{
Std_ReturnType ret;
/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CONTROLLER_MODE_SID, ETHIF_E_UNINIT);
		return V2X_E_NOT_OK;
	}

	if(CtrlIdx >EthIf_ConfigPointer->numberControllers)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CONTROLLER_MODE_SID, ETHIF_E_INV_CTRL_IDX);
		return V2X_E_NOT_OK;
	}

	if(NULL_PTR == CtrlModePtr)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CONTROLLER_MODE_SID, ETHIF_E_PARAM_POINTER);
		return V2X_E_NOT_OK;
	}
#endif

/* Check that Wireless Ethernet Standard is ON */
#if(ETHIF_ENABLE_WETH_API==STD_ON)
/* No VLAN Support */
ret = WEth_GetControllerMode(EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId, CtrlModePtr);
ethmode = *CtrlModePtr;
#elif
return V2X_E_NOT_OK;
#endif
return ret;
}


/************************************************************************************
* Service Name: EthIf_TxConfirmation
* Service ID[hex]: 0x11
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx, BufIdx, Result
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Confirms frame transmission by the indexed controller.
* Requirements: SWS_EthIf_00255, SWS_EthIf_00092,SWS_EthIf_00093, SWS_EthIf_00094
************************************************************************************/
void EthIf_TxConfirmation( uint8 CtrlIdx, Eth_BufIdxType BufIdx,Std_ReturnType Result) {
    uint8 i;
    uint8 txhandle;
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TX_CONFIRMATION_SID, ETHIF_E_UNINIT);
		return;
	}

	if (CtrlIdx > EthIf_ConfigPointer->numberControllers)
		{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TX_CONFIRMATION_SID, ETHIF_E_INV_CTRL_IDX);
			return;
		}
	if(BufIdx > EthIf_ConfigPointer->EthCtrls[CtrlIdx].MaxTxBufsTotal)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TX_CONFIRMATION_SID, ETHIF_E_INV_PARAM);
		return;
	}

#endif
    /* TX Confirmation function to UL is valid and transmission Succeed */
    if(NULL_PTR!= EthIf_ConfigPointer->EthIfULTxConfirmation)
    {
        for (i=0; i < EthIf_ConfigPointer->EthIfOwnersCount; i++) {

            if (BufIdx == EthIfCurrentState.ethIfCurrentDataInfo[i].bufferIdx ) {

                /* get The Frame Owner Index */
                txhandle=EthIf_ConfigPointer->EthIfOwnerCfg[i].EthIfFrameOwnerConfig;
                /* Call The GeoNetwork function that correspond to the owner */
                 EthIf_ConfigPointer->EthIfULTxConfirmation[txhandle]( CtrlIdx, BufIdx,Result);

                 break;
            }
        }
    }

}




#if (ETHIF_ENABLE_WETH_API==STD_ON)
/************************************************************************************
* Service Name: EthIf_GetBufWRxParams
* Service ID[hex]: 0x32
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx, RxParamIds, NumParams
* Parameters (inout): None
* Parameters (out): ParamValues
* Return value: V2X_E_OK: success
				V2X_E_NOT_OK: failed reading parameters
* Description: Read out values related to the receive direction of the transceiver for a receivedpacket. For example, this could be RSSI or Channel belonging to one singlepacket.
* Requirements: SWS_EthIf_00341, SWS_EthIf_00342,SWS_EthIf_00343, SWS_EthIf_00344SWS_EthIf_00345, SWS_EthIf_00346
************************************************************************************/

Std_ReturnType EthIf_GetBufWRxParams (uint8 CtrlIdx,const WEth_BufWRxParamIdType* RxParamIds,uint32* ParamValues,uint8 NumParams)
{
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WRX_PARAMS_SID, ETHIF_E_UNINIT);
		return V2X_E_NOT_OK;
	}

	if (CtrlIdx > EthIf_ConfigPointer->numberControllers)
	{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WRX_PARAMS_SID, ETHIF_E_INV_CTRL_IDX);
			return V2X_E_NOT_OK;
	}
	if(RxParamIds ==NULL_PTR)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WRX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
		return V2X_E_NOT_OK;
	}
	if(ParamValues ==NULL_PTR)
	{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WRX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
			return V2X_E_NOT_OK;
	}

#endif

	Std_ReturnType ret;
	ret=WEth_GetBufWRxParams (EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId,RxParamIds,ParamValues, NumParams);

	return ret;

}
#endif



#if (ETHIF_ENABLE_WETH_API==STD_ON)
/************************************************************************************
* Service Name: EthIf_GetBufWTxParams
* Service ID[hex]: 0x31
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx, TxParamIds, NumParams
* Parameters (inout): None
* Parameters (out): ParamValues
* Return value: V2X_E_OK: success
				V2X_E_NOT_OK: failed reading parameters
* Description: Read out values related to the transmit direction of the transceiver for a transmitted packet. For example, this could be transaction ID belonging to one single packet
* Requirements: SWS_EthIf_00347, SWS_EthIf_00348,SWS_EthIf_00349, SWS_EthIf_00350, SWS_EthIf_00351, SWS_EthIf_00352
************************************************************************************/

Std_ReturnType EthIf_GetBufWTxParams(uint8 CtrlIdx,const WEth_BufWTxParamIdType* TxParamIds,uint32* ParamValues,uint8 NumParams)
{
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WTX_PARAMS_SID, ETHIF_E_UNINIT);
		return V2X_E_NOT_OK;
	}

	if (CtrlIdx >EthIf_ConfigPointer->numberControllers)
	{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WTX_PARAMS_SID, ETHIF_E_INV_CTRL_IDX);
			return V2X_E_NOT_OK;
	}

	if(TxParamIds ==NULL_PTR)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WTX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
		return V2X_E_NOT_OK;
	}

	if(ParamValues ==NULL_PTR)
	{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WTX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
			return V2X_E_NOT_OK;
	}

#endif

Std_ReturnType ret;
ret= WEth_GetBufWTxParams (EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId,TxParamIds,ParamValues,NumParams);
return ret;

}
#endif

#if (ETHIF_ENABLE_WETH_API==STD_ON)
/************************************************************************************
* Service Name: EthIf_SetBufWTxParams
* Service ID[hex]: 0x33
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx, BufIdx, TxParamIds, ParamValues, NumParams
* Parameters (inout): None
* Parameters (out): None
* Return value: V2X_E_OK: success
				V2X_E_NOT_OK: failed reading parameters
* Description: Set values related to the transmit direction of the transceiver for a specific buffer (packet to be sent). For example, this can be the desired transmit power or the channel belonging to one single packet.
* Requirements: SWS_EthIf_00353, SWS_EthIf_00354,SWS_EthIf_00355, SWS_EthIf_00356, SWS_EthIf_00357, SWS_EthIf_00358, SWS_EthIf_00359
************************************************************************************/

Std_ReturnType EthIf_SetBufWTxParams(uint8 CtrlIdx,Eth_BufIdxType BufIdx,const WEth_BufWTxParamIdType* TxParamIds,const uint32* ParamValues,uint8 NumParams)
{
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_UNINIT);
		return V2X_E_NOT_OK;
	}

	if (CtrlIdx > EthIf_ConfigPointer->numberControllers)
		{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_INV_CTRL_IDX);
			return V2X_E_NOT_OK;
		}
	if(TxParamIds ==NULL_PTR)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
		return V2X_E_NOT_OK;
	}
	if(ParamValues ==NULL_PTR)
	{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
			return V2X_E_NOT_OK;
	}
	if(BufIdx> EthIf_ConfigPointer->EthCtrls[CtrlIdx].MaxTxBufsTotal)
	{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_INV_PARAM);
			return V2X_E_NOT_OK;
	}

#endif

Std_ReturnType ret;
ret=  WEth_SetBufWTxParams (EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId, BufIdx, TxParamIds, ParamValues, NumParams);

return ret;

}
#endif

/************************************************************************************
* Service Name: EthIf_GetPhysAddr
* Service ID[hex]: 0x08
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx
* Parameters (inout): None
* Parameters (out): PhysAddrPtr
* Return value: None
* Description: Obtains the physical source address used by the indexed controller
* Requirements: SWS_EthIf_00062, SWS_EthIf_00063,SWS_EthIf_00064, SWS_EthIf_00065, SWS_EthIf_00357, SWS_EthIf_00358, SWS_EthIf_00359
************************************************************************************/
void EthIf_GetPhysAddr (uint8 CtrlIdx, uint8* PhysAddrPtr)
{

/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
		/* Check if the Module is initialized before using this function */
		if (ETHCTRL_STATE_UNINIT == EthIf_State)
		{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_PHYS_ADDR_SID, ETHIF_E_UNINIT);
			return;
		}
		if (CtrlIdx > EthIf_ConfigPointer->numberControllers)
			{
				Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_PHYS_ADDR_SID, ETHIF_E_INV_CTRL_IDX);
				return;
			}
		if(PhysAddrPtr ==NULL_PTR)
			{
					Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_PHYS_ADDR_SID, ETHIF_E_PARAM_POINTER);
					return;
			}
#endif
/* Check that Wireless Ethernet Standard is ON */
#if(ETHIF_ENABLE_WETH_API==STD_ON)
		/* No VLAN Support */
		WEth_GetPhysAddr (EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId,PhysAddrPtr);
#endif


}

/************************************************************************************
* Service Name: EthIf_SetPhysAddr
* Service ID[hex]: 0x0d
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant for the same CtrlIdx, reentrant for different
* Parameters (in): CtrlIdx, PhysAddrPtr
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Sets the physical source address used by the indexed controller
* Requirements: SWS_EthIf_00134, SWS_EthIf_00135,SWS_EthIf_00136, SWS_EthIf_00137
************************************************************************************/
void EthIf_SetPhysAddr (uint8 CtrlIdx,const uint8* PhysAddrPtr)
{

/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
		/* Check if the Module is initialized before using this function */
		if (ETHCTRL_STATE_UNINIT == EthIf_State)
		{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_PHYS_ADDR_SID, ETHIF_E_UNINIT);
			return;
		}
		if (CtrlIdx > EthIf_ConfigPointer->numberControllers)
			{
				Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_PHYS_ADDR_SID, ETHIF_E_INV_CTRL_IDX);
				return;
			}
		if(PhysAddrPtr ==NULL_PTR)
			{
					Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_PHYS_ADDR_SID, ETHIF_E_PARAM_POINTER);
					return;
			}
#endif
/* Check that Wireless Ethernet Standard is ON */
#if(ETHIF_ENABLE_WETH_API==STD_ON)
		/* No VLAN Support */
		WEth_SetPhysAddr (EthIf_ConfigPointer->EthCtrls[CtrlIdx].EthIfWEthCtrlId,PhysAddrPtr);
#endif

}



/************************************************************************************
* Service Name: EthIf_CtrlModeIndication
* Service ID[hex]: 0xe
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant for the same CtrlIdx, reentrant for different
* Parameters (in): CtrlIdx, CtrlMode
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Called asynchronously when mode has been read out. Triggered by previous Eth_SetControllerMode call. Can directly be called within the trigger functions.
* Requirements: SWS_EthIf_00252
************************************************************************************/

void EthIf_CtrlModeIndication (uint8 CtrlIdx,Eth_ModeType CtrlMode)
{
	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_CTRL_MODE_INDICATION_SID, ETHIF_E_UNINIT);
		return;
	}

	if (CtrlIdx > EthIf_ConfigPointer->numberControllers)
		{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_CTRL_MODE_INDICATION_SID, ETHIF_E_INV_CTRL_IDX);
			return;
		}

#endif

EthSM_CtrlModeIndication (CtrlIdx, CtrlMode);

}

#if (ETHIF_ENABLE_WETH_API==STD_ON)

/************************************************************************************
* Service Name: EthIf_GetChanRxParams
* Service ID[hex]: 0x37
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): TrcvId Index of the transceiver, RadioId Index of the Transceiver's Radio ( including channel), ParamIds IDs of the Parameters to read, NumParams Number of Parameters to read
* Parameters (inout): None
* Parameters (out): ParamValues
* Return value: Std_ReturnType
* Description: Read values related to the receive direction of the transceiver. For example, this could be a Channel Busy Ratio (CBR) or the average Channel Idle Time (CIT).
* Requirements: SWS_EthIf_00380, SWS_EthIf_00381, SWS_EthIf_00382, SWS_EthIf_00383, SWS_EthIf_00384, SWS_EthIf_00385, SWS_EthIf_00386
************************************************************************************/
Std_ReturnType EthIf_GetChanRxParams (uint8 TrcvId,uint8 RadioId,const WEthTrcv_GetChanRxParamIdType* ParamIds,uint32* ParamValues,uint8 NumParams)
{

	/* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
	/* Check if the Module is initialized before using this function */
	if (ETHCTRL_STATE_UNINIT == EthIf_State)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CHAN_RX_PARAMS_SID, ETHIF_E_UNINIT);
		return V2X_E_NOT_OK;
	}

	if(ParamIds ==NULL_PTR)
	{
		Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CHAN_RX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
		return V2X_E_NOT_OK;
	}

	if(ParamValues ==NULL_PTR)
	{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CHAN_RX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
			return V2X_E_NOT_OK;
	}

#endif

	//return WEthTrcv_GetChanRxParams(&TrcvId,RadioId,ParamIds,ParamValues,NumParams);
	return V2X_E_OK;
}

#endif


/************************************************************************************
* Service Name: EthIf_SetRadioParams
* Service ID[hex]: 0x34
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): TrcvId, ParamIds,ParamValue, NumParams
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType
* Description: Set values related to a transceiver's wireless radio. For example, this could be the selection of the radio settings (channel, ...).
* Requirements: SWS_EthIf_00360, SWS_EthIf_00361, SWS_EthIf_00362, SWS_EthIf_00363, SWS_EthIf_00364, SWS_EthIf_00365
************************************************************************************/
Std_ReturnType EthIf_SetRadioParams (uint8 TrcvId,const WEthTrcv_SetRadioParamIdType* ParamIds,const uint32* ParamValue,uint8 NumParams){

	/* Requirement: SWS_EthIf_00008 */
	#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
		/* Check if the Module is initialized before using this function */
		if (ETHCTRL_STATE_UNINIT == EthIf_State)
		{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_RADIO_PARAMS_SID, ETHIF_E_UNINIT);
			return V2X_E_NOT_OK;
		}

		if(ParamIds ==NULL_PTR)
		{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_RADIO_PARAMS_SID, ETHIF_E_PARAM_POINTER);
			return V2X_E_NOT_OK;
		}

		if(ParamValue ==NULL_PTR)
		{
				Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_RADIO_PARAMS_SID, ETHIF_E_PARAM_POINTER);
				return V2X_E_NOT_OK;
		}

	#endif

	//return  WEthTrcv_SetRadioParams (TrcvId, ParamIds,ParamValue, NumParams);
		return V2X_E_OK;
}

#if (ETHIF_ENABLE_WETH_API==STD_ON)
/************************************************************************************
* Service Name: EthIf_SetChanRxParams
* Service ID[hex]: 0x35
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): TrcvId,RadioId,ParamIds,ParamValues,NumParams
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType
* Description: Set values related to the receive direction of a transceiver's wireless channel. For example, this could be a channel parameter like the frequency
* Requirements: SWS_EthIf_00366, SWS_EthIf_00367, SWS_EthIf_00368, SWS_EthIf_00369, SWS_EthIf_00370, SWS_EthIf_00371, SWS_EthIf_00372
************************************************************************************/
Std_ReturnType EthIf_SetChanRxParams (uint8 TrcvId,uint8 RadioId,const WEthTrcv_SetChanRxParamIdType* ParamIds,const uint32* ParamValues,uint8 NumParams){

	/* Requirement: SWS_EthIf_00008 */
	#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
		/* Check if the Module is initialized before using this function */
		if (ETHCTRL_STATE_UNINIT == EthIf_State)
		{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CHAN_RX_PARAMS_SID, ETHIF_E_UNINIT);
			return V2X_E_NOT_OK;
		}

		if(ParamIds == NULL_PTR)
		{
			Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CHAN_RX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
			return V2X_E_NOT_OK;
		}

		if(ParamValues == NULL_PTR)
		{
				Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CHAN_RX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
				return V2X_E_NOT_OK;
		}

	#endif

	//return WEthTrcv_SetChanRxParams (TrcvId,RadioId,ParamIds,ParamValues,NumParams);
		return V2X_E_OK;
}

#endif
#if (ETHIF_ENABLE_WETH_API==STD_ON)

Std_ReturnType EthIf_SetChanTxParams (uint8 TrcvId,uint8 RadioId,const WEthTrcv_SetChanTxParamIdType* TxParamIds,const uint32* ParamValues,uint8 NumParams)
{


	/* Requirement: SWS_EthIf_00008 */
		#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
			/* Check if the Module is initialized before using this function */
			if (ETHCTRL_STATE_UNINIT == EthIf_State)
			{
				Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CHAN_TX_PARAMS_SID, ETHIF_E_UNINIT);
				return V2X_E_NOT_OK;
			}

			if(TxParamIds == NULL_PTR)
			{
				Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CHAN_TX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
				return V2X_E_NOT_OK;
			}

			if(ParamValues == NULL_PTR)
			{
					Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CHAN_TX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
					return V2X_E_NOT_OK;
			}

		#endif

		//return WEthTrcv_SetChanTxParams(TrcvId,RadioId,TxParamIds,ParamValues,NumParams);

			return V2X_E_OK;

}
#endif
