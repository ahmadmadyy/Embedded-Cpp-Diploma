
#include "../inc/EthIf.h"

/*
 * Module Version 1.0.0
 */
#define ETHIF_PBCFG_SW_MAJOR_VERSION              (1U)
#define ETHIF_PBCFG_SW_MINOR_VERSION              (0U)
#define ETHIF_PBCFG_SW_PATCH_VERSION              (0U)

/*
 * AUTOSAR Version 4.7.0
 */
#define ETHIF_PBCFG_AR_RELEASE_MAJOR_VERSION     (4U)
#define ETHIF_PBCFG_AR_RELEASE_MINOR_VERSION     (7U)
#define ETHIF_PBCFG_AR_RELEASE_PATCH_VERSION     (0U)

/* AUTOSAR Version checking between EthIf_PBcfg.c and EthIf.h files */
#if ((ETHIF_PBCFG_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
 ||  (ETHIF_PBCFG_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
 ||  (ETHIF_PBCFG_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of PBcfg.c does not match the expected version"
#endif

/* Software Version checking between EthIf_PBcfg.c and EthIf.h files */
#if ((ETHIF_PBCFG_SW_MAJOR_VERSION != ETHIF_SW_MAJOR_VERSION)\
 ||  (ETHIF_PBCFG_SW_MINOR_VERSION != ETHIF_SW_MINOR_VERSION)\
 ||  (ETHIF_PBCFG_SW_PATCH_VERSION != ETHIF_SW_PATCH_VERSION))
  #error "The SW version of PBcfg.c does not match the expected version"
#endif


/* All GeoNetworking frames shall use the EtherType value 0x8947 */
#define ETHIF_FRAME_TYPE                       (0x8947)
/* Selects the owner of an Ethernet frame type */
#define ETHIF_OWNER (0)
/* Physical Controller ID */
#define ETHIF_WETH_CTRL_ID (0)
/* Limits the total number of transmit buffers */
#define MAX_TXBUFS_TOTAL (1)
/* Specifies the maximum transmission unit (MTU) of the EthIfCtrl in [bytes] (Maximum). */
#define ETHIF_CTRL_MTU 1500
/* Number of configured Controllers */
#define NUMBER_CONTROLLER 1
/* Number of configured Owners */
#define NUMBER_OWNER 1

EthIf_Frame_Owner_type owner={ETHIF_FRAME_TYPE,ETHIF_OWNER};
const EthIf_ControllerType ctrl={ETHIF_CTRL_IDX,ETHIF_WETH_CTRL_ID,MAX_TXBUFS_TOTAL,ETHIF_CTRL_MTU};
EthIfULTxConfirmationType   EthIfULTxConfirmation = {&V2xGn_TxConfirmation};
EthIfULRxIndicationType  EthIfULRxIndication = {&V2xGn_RxIndication};

/* PB structure used with EthIf_Init API */
const EthIf_ConfigType ethif_congif={
			&owner,
			&ctrl,
			NUMBER_CONTROLLER,
			&EthIfULTxConfirmation,&EthIfULRxIndication,NUMBER_OWNER};
