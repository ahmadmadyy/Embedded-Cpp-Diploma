#ifndef ETHIF_CBK_H_
#define ETHIF_CBK_H_

#include "../../General/Eth_GeneralTypes.h"

void EthIf_RxIndication( uint8 CtrlIdx, Eth_FrameType FrameType, boolean IsBroadcast, const uint8* PhysAddrPtr, Eth_DataType* DataPtr, uint16 LenByte );
void EthIf_TxConfirmation( uint8 CtrlIdx, Eth_BufIdxType BufIdx,Std_ReturnType Result);
void EthIf_CtrlModeIndication( uint8 CtrlIdx, Eth_ModeType CtrlMode );

#endif /* ETHIF_CBK_H_ */
