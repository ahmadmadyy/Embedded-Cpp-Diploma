/*
 ============================================================================
 Name        : EthIf.h
 Author      : Nouran Hussein
 Version     :
 Description : Header File for Ethernet Interface Module Supporting Wireless Ethernet Driver.
 ============================================================================
 */

#ifndef ETHIF_H
#define ETHIF_H

/* Id for the company in the AUTOSAR */
#define ETHIF_VENDOR_ID    (1000U)

/* EthIf Module Id */
#define ETHIF_MODULE_ID    (065U)

/* EthIf Instance Id */
#define ETHIF_INSTANCE_ID  (0U)

/*
 * Module Version 1.0.0
 * Requirement: SWS_EthIf_00006
 */
#define ETHIF_SW_MAJOR_VERSION           (1U)
#define ETHIF_SW_MINOR_VERSION           (0U)
#define ETHIF_SW_PATCH_VERSION           (0U)

/*
 * AUTOSAR Version 4.7.0
 */
#define ETHIF_AR_RELEASE_MAJOR_VERSION   (4U)
#define ETHIF_AR_RELEASE_MINOR_VERSION   (7U)
#define ETHIF_AR_RELEASE_PATCH_VERSION   (0U)

/*
 * Macros for EthIf Status
 */
#define ETHIF_INITIALIZED                (1U)
#define ETHIF_NOT_INITIALIZED            (0U)


#include"../../General/WEth_GeneralTypes.h"

/*
 * AUTOSAR Version checking between WEth_GeneralTypes.h and EthIf.h files
 * Requirement: SWS_EthIf_00007
*/
#if ((WETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
 ||  (WETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
 ||  (WETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of WEth.h does not match the expected version"
#endif


#include"../../V2xWEth/inc/WEth.h"

/*
 * AUTOSAR Version checking between WEth.h and EthIf.h files
 * Requirement: SWS_EthIf_00007
*/
#if ((WETH_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
 ||  (WETH_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
 ||  (WETH_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of WEth.h does not match the expected version"
#endif

#include"../../V2xGn/inc/V2xGn_Cbk.h"
/*
 * AUTOSAR Version checking between V2xGn.h and EthIf.h files
 * Requirement: SWS_EthIf_00007
*/
#if (( V2XGN_CBK_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
 ||  (V2XGN_CBK_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
 ||  (V2XGN_CBK_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of WEth.h does not match the expected version"
#endif



/* EthIf Pre-Compile Configuration Header file */
#include "../../V2xEthIf/inc/EthIf_Cfg.h"


/* AUTOSAR Version checking between EthIf_Cfg.h and EthIf.h files
 * Requirement: SWS_EthIf_00007
 *
 *  */
#if ((ETHIF_CFG_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
 ||  (ETHIF_CFG_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
 ||  (ETHIF_CFG_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of EthIf_Cfg.h does not match the expected version"
#endif

/* Software Version checking between EthIf_Cfg.h and EthIf.h files
 * Requirement: SWS_EthIf_00007
 *  */
#if ((ETHIF_CFG_SW_MAJOR_VERSION != ETHIF_SW_MAJOR_VERSION)\
 ||  (ETHIF_CFG_SW_MINOR_VERSION != ETHIF_SW_MINOR_VERSION)\
 ||  (ETHIF_CFG_SW_PATCH_VERSION != ETHIF_SW_PATCH_VERSION))
  #error "The SW version of EthIf_Cfg.h does not match the expected version"
#endif

/* including Ethernet State Manager for informing about Ethernet Mode */
#include "../../EthSM/inc/EthSM.h"

#include "../../General/Eth_GeneralTypes.h"

/* AUTOSAR Version checking between Eth_GeneralTypes.h and EthIf.h files
 * Requirement: SWS_EthIf_00007
 *  */
#if ((ETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
 ||  (ETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
 ||  (ETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of WEth.h does not match the expected version"
#endif


/******************************************************************************
 *                      API Service Id Macros                                 *
 ******************************************************************************/

 /* Service ID for EthIf Init */
 #define ETHIF_INIT_SID		(uint8)0x01
/* Service ID for EthIf ProvideTxBuffer*/
#define ETHIF_PROVIDE_TX_BUFFER_SID (uint8)0x09
/*  Service ID for EthIf Transmit */
#define ETHIF_TRANSMIT_SID (uint8)0x0A
/*  Service ID for EthIf Receive indication  */
#define ETHIF_RX_INDICATION_SID (uint8)0x10
/* Service ID for EthIf Main Function Rx */
#define ETHIF_MAIN_FUNCTION_RX_SID	 (uint8)0x20
/* Service ID for EthIf Main Function Tx */
#define ETHIF_MAIN_FUNCTION_TX_SID  (uint8)0x21
/*Service ID for EthIf Get Version Info */
#define ETHIF_GET_VERSION_INFO_SID (uint8)0x0b
/*Service ID for EthIf set Controller mode */
#define ETHIF_SET_CONTROLLER_MODE_SID (uint8)0x03
/*Service ID for EthIf get Controller mode */
#define ETHIF_GET_CONTROLLER_MODE_SID (uint8)0x04
/*Service ID for EthIf transmission confirmation */
#define ETHIF_TX_CONFIRMATION_SID (uint8)0x11
/*Service ID for EthIf that Read out values related to the receive direction of the transceiver for a received packet*/
#define ETHIF_GET_BUF_WRX_PARAMS_SID (uint8)0x32
/*Service ID for EthIf that Read out values related to the transmit direction of the transceiver for a transmitted packet*/
#define ETHIF_GET_BUF_WTX_PARAMS_SID (uint8)0x31
/*Service ID for EthIf that Set values related to the transmit direction of the transceiver for a specific buffer(packet to be sent)*/
#define ETHIF_SET_BUF_WTX_PARAMS_SID (uint8)0x33
/*Service ID for EthIf Obtains the physical source address used by the indexed controller */
#define ETHIF_GET_PHYS_ADDR_SID (uint8)0x08
/*Service ID for EthIf Sets the physical source address used by the indexed controller */
#define ETHIF_SET_PHYS_ADDR_SID (uint8)0x0d
/*Service ID for EthIf Called asynchronously when mode has been read out */
#define ETHIF_CTRL_MODE_INDICATION_SID (uint8)0x0e
#define ETHIF_GET_CHAN_RX_PARAMS_SID (uint8)0x37
#define ETHIF_SET_RADIO_PARAMS_SID 	(uint8)0x34
#define ETHIF_SET_CHAN_RX_PARAMS_SID	(uint8)0x35
#define ETHIF_SET_CHAN_TX_PARAMS_SID	(uint8)0x36
/*******************************************************************************
 *                      DET Error Codes                                        *
 *******************************************************************************/

 /* API service called with invalid controller index */
 #define ETHIF_E_INV_CTRL_IDX		(uint8)0x01

 /* API service called when EthIf module was not initialized */
 #define ETHIF_E_UNINIT		(uint8)0x05

 /* API service called with invalid pointer in parameter list */
 #define ETHIF_E_PARAM_POINTER		(uint8)0x06

 /* API service called with invalid parameter */
 #define ETHIF_E_INV_PARAM		(uint8)0x07

 /* EthIf_Init called with an invalid configuration pointer */
 #define ETHIF_E_INIT_FAILED		(uint8)0x08

 /* Invalid port index */
 #define ETHIF_E_INV_PORT_IDX		(uint8)0x09

 /*******************************************************************************
 *                              Function Pointer Types                              *
 *******************************************************************************/

 /* Function pointer for User defined Tx Confirmation callback */
 typedef void (*EthIfULTxConfirmationType) ( uint8 CtrlIdx, uint8 BufIdx,Std_ReturnType Result );

 /* Function pointer for User defined Rx Indication callback */
 typedef void (*EthIfULRxIndicationType) ( uint8 CtrlIdx, Eth_FrameType FrameType, boolean IsBroadcast, const uint8* PhysAddrPtr, uint8* DataPtr, uint16 LenByte );

 /*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/
 /*Index to select specific measurement data*/
 typedef uint8 EthIf_MeasurementIdxType;

 typedef char* EcucFunctionNameDef ;

typedef enum{ETHCTRL_STATE_UNINIT, ETHCTRL_STATE_INIT}EthIf_StateType;

typedef struct {
    uint32 EthIfFrameType;   /* Frame Type */
    uint8 EthIfFrameOwnerConfig; /* Selects the owner of an Ethernet frame type. The owner is a zero based index into the callback function configuration 'EthIfRxIndicationConfig' */
}EthIf_Frame_Owner_type;
typedef struct{

	 uint8 WEthCtrlId;
	 uint8 WEthCtrlPhyAddress[17];
	 uint16 WEthCtrlRxBufLenByte;
	 uint16 WEthCtrlTxBufLenByte;
	 uint8 WEthRxBufTotal;
	 uint8 WEthTxBufTotal;

}WEthCtrlType;

typedef struct{
	uint8 PhysCtrlId;
	WEthCtrlType* PhysWEthCtrlRef;
}EthIf_PhysControllerType;


/* Implementation for Ethernet Interface Wireless Controller type structure */
typedef struct{

/* array of Wireless Ethernet  */
uint8 CtrlIdx;
/* Index of Wireless Ethernet controller within the context of the Ethernet Driver */
uint8 EthIfWEthCtrlId;
/* Limits the total number of transmit buffers */
uint8 MaxTxBufsTotal;
/* maximum transmission unit*/
uint32 CtrlMtu;

}EthIf_ControllerType;


 /* Implementation specific structure of the post build configuration */
typedef struct{
	 const EthIf_Frame_Owner_type* EthIfOwnerCfg;  /* pointer to hold Owner data */
     const EthIf_ControllerType * EthCtrls; /* pointer to hold controllers data */
	 uint8  numberControllers;    /* Number of Controllers */
	 const EthIfULTxConfirmationType*    EthIfULTxConfirmation; /* pointer to hold Tx confirmation functions list */
	 const EthIfULRxIndicationType *     EthIfULRxIndication; /* Ptr to Rx indication function list */
	 uint8 EthIfOwnersCount;   /* Number of Owners */

}EthIf_ConfigType;


/*******************************************************************************
 *                      Function Prototypes                                    *
 *******************************************************************************/

 void EthIf_Init (const EthIf_ConfigType* CfgPtr);
 BufReq_ReturnType EthIf_ProvideTxBuffer( uint8 CtrlIdx, Eth_FrameType FrameType, uint8 Priority, Eth_BufIdxType* BufIdxPtr, uint8** BufPtr, uint16*LenBytePtr );
 Std_ReturnType EthIf_GetBufWRxParams (uint8 CtrlIdx,const WEth_BufWRxParamIdType* RxParamIds,uint32* ParamValues,uint8 NumParams);
 void EthIf_TxConfirmation( uint8 CtrlIdx, Eth_BufIdxType BufIdx,Std_ReturnType Result);
 Std_ReturnType EthIf_GetControllerMode( uint8 CtrlIdx, Eth_ModeType* CtrlModePtr );
 Std_ReturnType EthIf_SetControllerMode( uint8 CtrlIdx, Eth_ModeType CtrlMode );
 void EthIf_RxIndication( uint8 CtrlIdx, Eth_FrameType FrameType, boolean IsBroadcast, const uint8* PhysAddrPtr, Eth_DataType* DataPtr, uint16 LenByte );
 Std_ReturnType EthIf_Transmit( uint8 CtrlIdx, Eth_BufIdxType BufIdx, Eth_FrameType FrameType, boolean TxConfirmation, uint16 LenByte, const uint8* PhysAddrPtr );
 Std_ReturnType EthIf_GetBufWTxParams(uint8 CtrlIdx,const WEth_BufWTxParamIdType* TxParamIds,uint32* ParamValues,uint8 NumParams);
 Std_ReturnType EthIf_SetBufWTxParams(uint8 CtrlIdx,Eth_BufIdxType BufIdx,const WEth_BufWTxParamIdType* TxParamIds,const uint32* ParamValues,uint8 NumParams);
void EthIf_GetVersionInfo( Std_VersionInfoType* VersionInfoPtr );
void EthIf_MainFunctionTx( void );
void EthIf_MainFunctionRx( void );
void EthIf_GetPhysAddr (uint8 CtrlIdx, uint8* PhysAddrPtr);
void EthIf_SetPhysAddr (uint8 CtrlIdx,const uint8* PhysAddrPtr);
void EthIf_CtrlModeIndication (uint8 CtrlIdx,Eth_ModeType CtrlMode);
Std_ReturnType EthIf_GetChanRxParams (uint8 TrcvId,uint8 RadioId,const WEthTrcv_GetChanRxParamIdType* ParamIds,uint32* ParamValues,uint8 NumParams);
Std_ReturnType EthIf_SetRadioParams (uint8 TrcvId,const WEthTrcv_SetRadioParamIdType* ParamIds,const uint32* ParamValue,uint8 NumParams);
Std_ReturnType EthIf_SetChanRxParams (uint8 TrcvId,uint8 RadioId,const WEthTrcv_SetChanRxParamIdType* ParamIds,const uint32* ParamValues,uint8 NumParams);
Std_ReturnType EthIf_SetChanTxParams (uint8 TrcvId,uint8 RadioId,const WEthTrcv_SetChanTxParamIdType* TxParamIds,const uint32* ParamValues,uint8 NumParams);

/*******************************************************************************
 *                      external Variables                                    *
 *******************************************************************************/
extern const EthIf_ControllerType ctrl;
extern const EthIf_ConfigType ethif_congif;
#endif /* ETHIF_H */
