 /*
 ============================================================================
 Name        : EthIf.c
 Author      : Nouran Hussein
 Version     :
 Description : Pre-Compile Configuration Header file for Ethernet Interface Module Supporting Wireless Ethernet Driver.
 ============================================================================
 */

#ifndef ETHIF_CFG_H
#define ETHIF_CFG_H


/*
 * Module Version 1.0.0
 */
#define ETHIF_CFG_SW_MAJOR_VERSION           (1U)
#define ETHIF_CFG_SW_MINOR_VERSION           (0U)
#define ETHIF_CFG_SW_PATCH_VERSION           (0U)

/*
 * AUTOSAR Version 4.7.0
 */
#define ETHIF_CFG_AR_RELEASE_MAJOR_VERSION   (4U)
#define ETHIF_CFG_AR_RELEASE_MINOR_VERSION   (7U)
#define ETHIF_CFG_AR_RELEASE_PATCH_VERSION   (0U)

/* Pre-compile option for Development Error Detect
 * SWS Item: ECUC_EthIf_00004
 * */
#define ETHIF_DEV_ERROR_DETECT                (STD_ON)

/* Pre-compile option for Version Info API
 * SWS Item: ECUC_EthIf_00007
 * */
#define ETHIF_VERSION_INFO_API                (STD_ON)

/* Pre-compile option for Enables / Disables receive interrupt
 * SWS Item: ECUC_EthIf_00005
 *  */
#define ETHIF_ENABLE_RX_INTERRUPT				  (STD_OFF)

/* Pre-compile option for Enables / Disables transmit interrupt
 * SWS Item: ECUC_EthIf_00006
 *
 *  */
#define ETHIF_ENABLE_TX_INTERRUPT				  (STD_OFF)

/* Pre-compile option for Enables / Disables API's for WEth
 * SWS Item: ECUC_EthIf_00075
 * */
#define ETHIF_ENABLE_WETH_API					  (STD_ON)

/* Pre-compile option Specifies the period of main function EthIf_MainFunctionRx in seconds
 * SWS Item: ECUC_EthIf_00023
 * */
#define ETHIF_MAIN_FUNCTION_PERIOD

/* Pre-compile option which provides a zero-based consecutive index of the Ethernet Communication Controllers
 * SWS Item: ECUC_EthIf_00026
 *  */
#define ETHIF_CTRL_IDX                          (0U)

/*  Pre-compile option which Max number of Ethernet frames polled per main function invocation
 * SWS Item: ECUC_EthIf_00030
 *  */
#define ETHIF_RX_INDICATION_ITERATIONS			  (30U)

/* Pre-compile option which Enables / Disables GetCtrlIdxList API
 * SWS Item: ECUC_EthIf_00070
 *
 *  */
#define ETHIF_GET_CTRL_IDX_LIST					  (STD_OFF)



#endif /* ETHIF_CFG_H */
