/*
 * NvM_Cbk.h
 *
 *  Created on: Mar 3, 2022
 *      Author: MBR
 */

#ifndef CRYPTO_CBK_H_
#define CRYPTO_CBK_H_
#include"../../General/Std_Types.h"

Std_ReturnType Crypto_11_STM32F429_NvBlock_ReadFrom_storedKey(const void* NvmBuffer);


#endif /* CRYPTO_CBK_H_ */
